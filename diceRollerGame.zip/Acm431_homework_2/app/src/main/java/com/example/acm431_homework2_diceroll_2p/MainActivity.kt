package com.example.acm431_homework2_diceroll_2p

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    var TAG:String = "MainActivity"
    var random_number:Int = 0
    var SCORE_PLAYER_1:Int = 0
    var SCORE_PLAYER_2:Int = 0
    var ACTIVE_PLAYER_1:Boolean = true
    var ACTIVE_PLAYER_2:Boolean = false
    var GAME_POINT:Int = 50
    var GAME_END_MSG:String? = null
    var GAME_END_MSG_DEFAULT:String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // disabling dice_image
        dice_image.isEnabled = false

        btnGamePlay.setOnClickListener{
            //enabling dice_image
            dice_image.isEnabled = true

            textView2.isEnabled = false
            textView3.isEnabled = false

            //reseting the scores for the players
            SCORE_PLAYER_1 = 0
            SCORE_PLAYER_2 = 0

            //clearing the text view and set the default value
            tvGameOverMsg.text = ""
            tvGamePoint1.text = "0"
            tvGamePoint2.text = "0"

            //enabling player1 to start again
            ACTIVE_PLAYER_1 = true
            ACTIVE_PLAYER_2 = false

            //reset the image to dice1
            dice_image.setImageResource(R.drawable.dice_1)
        }

        dice_image.setOnClickListener {

            random_number = (1..6).random()

            when(random_number){
                1 -> {
                    dice_image.setImageResource(R.drawable.dice_1)
                }
                2 -> {
                    dice_image.setImageResource(R.drawable.dice_2)
                }
                3 -> {
                    dice_image.setImageResource(R.drawable.dice_3)
                }
                4 -> {
                    dice_image.setImageResource(R.drawable.dice_4)
                }
                5 -> {
                    dice_image.setImageResource(R.drawable.dice_5)
                }
                6 -> {
                    dice_image.setImageResource(R.drawable.dice_6)
                }
            }

            if (ACTIVE_PLAYER_1){
                SCORE_PLAYER_1 += random_number
                tvGamePoint1.text = SCORE_PLAYER_1.toString()
                ACTIVE_PLAYER_1 = false
                ACTIVE_PLAYER_2 = true

                //check the game point(winner)
                if (SCORE_PLAYER_1 >= 50){
                    GAME_END_MSG_DEFAULT = resources.getText(R.string.game_over_msg).toString()
                    GAME_END_MSG = GAME_END_MSG_DEFAULT + "Player 1"
                    tvGameOverMsg.text = GAME_END_MSG
                    //dice roll is disabled
                    dice_image.isEnabled = false
                }
            }

            else if (ACTIVE_PLAYER_2){
                SCORE_PLAYER_2 += random_number
                tvGamePoint2.text = SCORE_PLAYER_2.toString()
                ACTIVE_PLAYER_2 = false
                ACTIVE_PLAYER_1 = true

                //check the game point(winner)
                if(SCORE_PLAYER_2 >= 50){
                    GAME_END_MSG_DEFAULT = resources.getText(R.string.game_over_msg).toString()
                    GAME_END_MSG = GAME_END_MSG_DEFAULT + "Player 2"
                    tvGameOverMsg.text = GAME_END_MSG
                    //dice roll is disabled
                    dice_image.isEnabled = false
                }
            }

            Log.e(TAG,random_number.toString())
            }
        }
    }
